package com.cm.MavenProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MavenProject1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
